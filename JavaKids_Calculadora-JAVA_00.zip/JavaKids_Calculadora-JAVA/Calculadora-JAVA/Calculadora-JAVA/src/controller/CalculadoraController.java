package controller;

import controller.ext.CalculadoraExt;
import view.CalculadoraView;

public class CalculadoraController {

    private final CalculadoraView view;
    private final CalculadoraExt helper;

    public CalculadoraController(CalculadoraView view) {
        this.view = view;  // chamando view
        view.setLocationRelativeTo(null); // centralziar calculadora
        this.helper = new CalculadoraExt(view);
    }

    public void atualizarNumeroExibido(String num) {
        this.helper.concatenarNoDisplay(num);
    }

    public void limparTela() {
        this.helper.limpar();
    }

    public void definirOperacao(String op) {

        String numDoDisplay = this.helper.pegarNumeroDoDisplay();

        if (numDoDisplay.equals("")) //Se não tem nenhum número no display, encerra o metodo
        {
            return;
        }

        //Define o numero1 e operacao
        this.view.setNum1(numDoDisplay);
        this.view.setOperacao(op);

        //Limpa o display
        this.helper.limpar();
    }

    public void exibirResultado() {

        String txtNumero1 = this.view.getNum1();
        String operacao = this.view.getOperacao();
        String txtNumero2 = this.helper.pegarNumeroDoDisplay();

        //Se não tiver numero1, encerra o método.
        if (txtNumero1.equals("")) {
            return;
        }

        //Se não tiver número no display, o resultado é o próprio numero1
        if (txtNumero2.equals("")) {
            this.helper.exibir(txtNumero1);
        }

        //Se tiver nnumero1, e algum numero no display
        //Guarda o numero2 na variavel
        this.view.setNum2(txtNumero2);

        //Calcula o resultado da operacao
        float resultado = 0;

        //Soma Arthur
        if (operacao.equals("+")) {
            resultado = Float.parseFloat(txtNumero1) + Float.parseFloat(txtNumero2);
        }//Subtração Renan
        else if (operacao.equals("-")) {
            resultado = Float.parseFloat(txtNumero1) - Float.parseFloat(txtNumero2);
        } //Multiplicação Maçã
        else if (operacao.equals("x")) {
            resultado = Float.parseFloat (txtNumero1) * Float.parseFloat(txtNumero2);
        } //Divisão Gabriel Lindão
        else if (operacao.equals("/")) {
            resultado = Float.parseFloat (txtNumero1) / Float.parseFloat (txtNumero2);
        }

            /*
        //Soma
        switch (operacao) {
            case "+":
                resultado = Float.parseFloat(txtNumero1) + Float.parseFloat(txtNumero2);
                //Subtração
                break;
            case "-":
                resultado = Float.parseFloat(txtNumero1) - Float.parseFloat(txtNumero2);
                //Multiplicação
                break;
            case "x":
                resultado = Float.parseFloat(txtNumero1) * Float.parseFloat(txtNumero2);
                //Divisão
                break;
            case "/":
                resultado = Float.parseFloat(txtNumero1) / Float.parseFloat(txtNumero2);
                break;
            default:
                break;
        }*/
            
            
            //apresentando valor
            this.helper.exibir(String.valueOf(resultado));

        }

    }
